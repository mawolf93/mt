rm(list = ls(all.names = TRUE))
library(ggplot2)
library(BLModel)
library(PerformanceAnalytics)
library(xts)
library(moments)
library(matlib)
library(data.table)
library(stargazer)
library(psych)
library(RColorBrewer)
library(tidyr)
library(lmtest)
library(sandwich)

## loading data in

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./DATA_NEW/aggregate/sm aufgesplittet")
datadji <- as.data.frame(read.csv("DJI.csv", sep = ";", dec = ","))
dataes50 <- as.data.frame(read.csv("ES50.csv", sep = ";", dec = ","))
dataeur <- as.data.frame(read.csv("EUR.csv", sep = ";", dec = ","))
datagold <- as.data.frame(read.csv("GOLD.csv", sep = ";", dec = ","))
datajpy <- as.data.frame(read.csv("JPY.csv", sep = ";", dec = ","))
datamsci <- as.data.frame(read.csv("MSCI.csv", sep = ";", dec = ","))
datani225 <- as.data.frame(read.csv("NI225.csv", sep = ";", dec = ","))
dataoil <- as.data.frame(read.csv("OIL.csv", sep = ";", dec = ","))
datasp500 <- as.data.frame(read.csv("SP500.csv", sep = ";", dec = ","))


## renaming columns

colnames(datadji) <- c("Date", "dji", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(dataes50) <- c("Date", "es50", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(dataeur) <- c("Date", "eur", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datagold) <- c("Date", "gold", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datajpy) <- c("Date", "jpy", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datamsci) <- c("Date", "msci", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datani225) <- c("Date", "ni225", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(dataoil) <- c("Date", "oil", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datasp500) <- c("Date", "sp500", "X", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )


## dropping "unnecessary" data

datadji$Date <- as.Date(datadji$Date, "%d.%m.%Y")
datadji <- subset(datadji, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataes50$Date <- as.Date(dataes50$Date, "%d.%m.%Y")
dataes50 <- subset(dataes50, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataeur$Date <- as.Date(dataeur$Date, "%d.%m.%Y")
dataeur <- subset(dataeur, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datagold$Date <- as.Date(datagold$Date, "%d.%m.%Y")
datagold <- subset(datagold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datajpy$Date <- as.Date(datajpy$Date, "%d.%m.%Y")
datajpy <- subset(datajpy, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datamsci$Date <- as.Date(datamsci$Date, "%d.%m.%Y")
datamsci <- subset(datamsci, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datani225$Date <- as.Date(datani225$Date, "%d.%m.%Y")
datani225 <- subset(datani225, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataoil$Date <- as.Date(dataoil$Date, "%d.%m.%Y")
dataoil <- subset(dataoil, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datasp500$Date <- as.Date(datasp500$Date, "%d.%m.%Y")
datasp500 <- subset(datasp500, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))

## creating subsets before corona and corona subset

datadjics <- subset(datadji, Date >= as.Date("2020-01-01"))
datadjibc <- subset(datadji, Date < as.Date("2020-01-01"))
dataes50cs <- subset(dataes50, Date >= as.Date("2020-01-01"))
dataes50bc <- subset(dataes50, Date < as.Date("2020-01-01"))
dataeurcs <- subset(dataeur, Date >= as.Date("2020-01-01"))
dataeurbc <- subset(dataeur, Date < as.Date("2020-01-01"))
datagoldcs <- subset(datagold, Date >= as.Date("2020-01-01"))
datagoldbc <- subset(datagold, Date < as.Date("2020-01-01"))
datajpycs <- subset(datajpy, Date >= as.Date("2020-01-01"))
datajpybc <- subset(datajpy, Date < as.Date("2020-01-01"))
datamscics <- subset(datamsci, Date >= as.Date("2020-01-01"))
datamscibc <- subset(datamsci, Date < as.Date("2020-01-01"))
datani225cs <- subset(datani225, Date >= as.Date("2020-01-01"))
datani225bc <- subset(datani225, Date < as.Date("2020-01-01"))
dataoilcs <- subset(dataoil, Date >= as.Date("2020-01-01"))
dataoilbc <- subset(dataoil, Date < as.Date("2020-01-01"))
datasp500cs <- subset(datasp500, Date >= as.Date("2020-01-01"))
datasp500bc <- subset(datasp500, Date < as.Date("2020-01-01"))


## Model-estimation as function

doit <- function(set, cryp,trad){
  
  sink("trad.txt")
  writeLines(paste("datau <- data", trad, set,"$", trad,sep=""))
  closeAllConnections()
  source(file = "trad.txt")
  
  sink("cryp.txt")
  writeLines(paste("crypto <- data", trad,set, "$", cryp,sep=""))
  closeAllConnections()
  source(file = "cryp.txt")
  
  crypto <- na.omit(crypto)
  rem <- length(datau)-length(crypto)+1
  maxi <- length(datau)
  datau <- datau[rem:maxi]
  
  quan10 <- quantile(datau, probs=seq(0,1,0.1), na.rm=TRUE)
  quan5 <- quantile(datau, probs=seq(0,1,0.05), na.rm=TRUE)
  quan1 <- quantile(datau, probs=seq(0,1,0.01), na.rm=TRUE)
  dataSP <- as.data.frame(datau)
  colnames(dataSP) <- "ret"
  dataSP$tenp <- ifelse(dataSP$ret < quan10[2], 1,0)
  dataSP$fivep <- ifelse(dataSP$ret < quan5[2], 1,0)
  dataSP$onep <- ifelse(dataSP$ret < quan1[2], 1,0)
  dataSP$one <- 1
  
  ## garch
  
  library(fGarch)
  library(rugarch)
  
  fit.spec <- ugarchspec(variance.model     = list(model = "sGARCH",
                                                   garchOrder = c(1, 1)), 
                         mean.model         = list(armaOrder = c(0, 0),
                                                   include.mean = TRUE,
                                                   external.regressors = cbind(dataSP$ret*dataSP$one, dataSP$ret*dataSP$tenp, dataSP$ret*dataSP$fivep, dataSP$ret*dataSP$onep)), 
                         distribution.model = "norm")
  fit      <- ugarchfit(data = crypto, spec = fit.spec, trace=1)
  sink(paste("garchoutput0826/",cryp,trad,set,".txt",sep=""))
  print(fit)
  closeAllConnections()
  
}


## loop for all

set <- list("", "bc", "cs")
cryp <- list("BTC" , "ETH" , "XRP" , "USDT" , "BNB" , "XMR" ,  "EOS" , "ADA" , "LINK")
trad <- list("dji", "es50", "eur", "gold", "jpy", "msci", "ni225", "oil", "sp500")

for(x in set){
  for(y in cryp){
    for(z in trad){
      #daten=x
      #cryp=y
      #trad=z
      
      doit(x,y,z)
      
    }}}

## for trying
#doit("cs","BTC","dji")

## loop for the excel file
      
for(x in 1:3){
  for(y in 1:9){
    for(z in 1:9){
      xn=set[x]
      yn=cryp[y]
      zn=trad[z]
      
      martin <- paste(yn,zn,xn, sep="")
      print(martin)
    }}}





# Daily New Cases Graphic

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./covid data")
daily <- read.csv("newcases.csv", sep = ";", dec = ".")
colnames(daily) <- c("Date", "new_cases")
daily$Date <- as.Date(daily$Date, "%d.%m.%Y")
daily$mean <- frollmean(daily[, 2], 7)


ggplot(daily, aes(x=Date, y=new_cases,color="grey"))+
  geom_bar(stat = "identity", fill = "grey", color="black")+
  geom_line(data=daily, aes(x=Date, y=mean, color= "blue"), size=1.3)+
  scale_colour_manual(values = c( "blue"),
                      guide = guide_legend(override.aes = list(
                      linetype = "solid")),
                      labels = c("7-day moving average"))+
  theme(legend.position = c(0.128,0.9), #could give it in the middle after saving??
        legend.background = element_rect(fill="lightgrey", size=0.5, linetype="solid", color = "darkgrey"),
        legend.title = element_blank())+
  ylab("daily new cases")+
  scale_y_continuous(name="Daily New Cases", labels = scales::comma)+
  geom_vline(xintercept=daily$Date[214], colour="red", linetype = "longdash", size=1.5)


ggsave("dailycases.png", width = 12, height = 5)
dev.off()





# Summary statistics from normal returns

## N, mean, st.dev, min, max, percentage positive, SHARPE RATIO???

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./DATA_NEW/aggregate/")
datac <- read.csv("crypret.csv", sep = ";", dec = ",")
datat <- read.csv("tradret.csv", sep = ";", dec = ",")

datafc <- as.data.frame(datac)
dataft <- as.data.frame(datat)

colnames(datac) <- c("Date", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
colnames(datat) <- c("Date", "DJI", "ES50", "EUR", "GOLD", "JPY", "MSCI", "NI225", "OIL", "SP500" )

datac$Date <- as.Date(datac$Date, "%d.%m.%Y")
datat$Date <- as.Date(datat$Date, "%d.%m.%Y")

datafc <- datac[,-1]
dataft <- datat[,-1]
datafc <- datafc*100
dataft <- dataft*100
stargazer(datafc, summary.stat = c("n", "mean", "sd", "min","max") ,align=TRUE,no.space=TRUE)
#describe(datafc)
stargazer(dataft,summary.stat = c("n", "mean", "sd", "min","max") ,align=TRUE,no.space=TRUE)
#describe(dataft)

## percentage positive

for(i in 1:9){
percentagepositive <- round((sum(na.exclude(datafc[,i] > 0)))/(length(datafc[,i]) - sum(is.na(datafc[,i]))), 3)
print(percentagepositive)
}

for(i in 1:9){
  percentagepositive <- round((sum(na.exclude(dataft[,i] > 0)))/(length(dataft[,i]) - sum(is.na(dataft[,i]))), 3)
  print(percentagepositive)
}

## density plots

color=col=brewer.pal(n = 9, name = "Set1")

hist(rnorm(1000000, mean = mean(datafc[, 1]), 
           sd = sd(datafc[,1])), freq = FALSE, breaks = 100,
     ylim = c(0,0.3), main="", 
     xlab = "")
for (i in 1:9) {         
  lines(density(na.omit(datafc[,i])), col = color[i], lwd = 3)
}
legend("left", legend=colnames(datafc),text.width = 1/5,
       col=color, lty=1, bty = "n", cex=1, y.intersp = 1.8, x.intersp = 0.3, lwd=3)



color=col=brewer.pal(n = 9, name = "Set1")

hist(rnorm(1000000, mean = mean(dataft[, 6]), 
           sd = sd(dataft[,6])), freq = FALSE, breaks = 100,
     ylim = c(0,1), main = "", 
     xlab = "")
for (i in 1:9) {         
  lines(density(na.omit(dataft[,i])), col = color[i], lwd = 3)
}
legend("left", legend=colnames(dataft),text.width = 1/5,
       col=color, lty=1, bty = "n", cex=1, y.intersp = 1.8, x.intersp = 0.3, lwd=3)





# multi-Factor Models

## loading data in

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./data mfm/")
f3 <- read.csv("threefactorshort.csv", sep = ";", dec = ",")
f5 <- read.csv("fivefactorshort.csv", sep = ";", dec = ",")

## renaming and dropping

colnames(f3) <- c("Date", "Mkt.RF", "SMB", "HML", "RF", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
f3$Date <- as.Date(f3$Date, "%d.%m.%Y")
f3 <- subset(f3, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(f5) <- c("Date", "Mkt.RF", "SMB", "HML", "RMW", "CMA", "RF", "BTC", "ETH", "XRP", "USDT", "BNB", "XMR",  "EOS",  "ADA",  "LINK" )
f5$Date <- as.Date(f5$Date, "%d.%m.%Y")
f5 <- subset(f5, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))

## calculations in percentage terms

f3[,6:14] <- f3[,6:14]*100
f5[,8:16] <- f5[,8:16]*100

## creating subsets

f3cs <- subset(f3, Date >= as.Date("2020-01-01"))
f3bc <- subset(f3, Date < as.Date("2020-01-01"))
f5cs <- subset(f5, Date >= as.Date("2020-01-01"))
f5bc <- subset(f5, Date < as.Date("2020-01-01"))

## summary stat for big table

#summary(lm(LINK~Mkt.RF, data=f3))
#summary(lm(LINK~Mkt.RF+SMB+HML, data=f3))
#summary(lm(LINK~Mkt.RF+SMB+HML+RMW+CMA, data=f5))
#summary(lm(LINK~Mkt.RF, data=f3bc))
#summary(lm(LINK~Mkt.RF+SMB+HML, data=f3bc))
#summary(lm(LINK~Mkt.RF+SMB+HML+RMW+CMA, data=f5bc))
#summary(lm(LINK~Mkt.RF, data=f3cs))
#summary(lm(LINK~Mkt.RF+SMB+HML, data=f3cs))
#summary(lm(LINK~Mkt.RF+SMB+HML+RMW+CMA, data=f5cs))

## building a loop for one factor

set <- list("", "bc", "cs")
cryp <- list("BTC" , "ETH" , "XRP" , "USDT" , "BNB" , "XMR" ,  "EOS" , "ADA" , "LINK")

for(h in set){
  for(i in cryp) {
    
    sink("cryp.txt")
    writeLines(paste("one <- lm(", i, "~ Mkt.RF, data=f3", h, ")",sep=""))
    closeAllConnections()
    source(file = "cryp.txt")
    
    hallo <- coeftest(one,vcov=vcovHC(one,type="HC0",vcov. = vcovHC))
    sink(paste("1mfmoutput/",i,h,".txt",sep=""))
    print(hallo)
    closeAllConnections()
  }
}

## building a loop for three factors

set <- list("", "bc", "cs")
cryp <- list("BTC" , "ETH" , "XRP" , "USDT" , "BNB" , "XMR" ,  "EOS" , "ADA" , "LINK")

for(h in set){
  for(i in cryp) {
  
  sink("cryp.txt")
  writeLines(paste("three <- lm(", i, "~ Mkt.RF+SMB+HML, data=f3", h, ")",sep=""))
  closeAllConnections()
  source(file = "cryp.txt")

  hallo <- coeftest(three,vcov=vcovHC(three,type="HC0",vcov. = vcovHC))
  sink(paste("3mfmoutput/",i,h,".txt",sep=""))
  print(hallo)
  closeAllConnections()
  }
}

## building a loop for five factors

set <- list("", "bc", "cs")
cryp <- list("BTC" , "ETH" , "XRP" , "USDT" , "BNB" , "XMR" ,  "EOS" , "ADA" , "LINK")

for(h in set){
  for(i in cryp) {
    
    sink("cryp.txt")
    writeLines(paste("five <- lm(", i, "~ Mkt.RF+SMB+HML+RMW+CMA, data=f5", h, ")",sep=""))
    closeAllConnections()
    source(file = "cryp.txt")
    
    hallo <- coeftest(five,vcov=vcovHC(five,type="HC0",vcov. = vcovHC))
    sink(paste("5mfmoutput/",i,h,".txt",sep=""))
    print(hallo)
    closeAllConnections()
  }
}

## loop for the excel file

for(x in 1:3){
  for(y in 1:9){
      xn=set[x]
      yn=cryp[y]
      
      martin <- paste(yn,xn, sep="")
      print(martin)
    }}


# doing it for traddata

## loading data in
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./data mfm/trad/")
mfmsp500 <- read.csv("mfmSP500.csv", sep = ";", dec = ",")
mfmoil <- read.csv("mfmOIL.csv", sep = ";", dec = ",")
mfmni225 <- read.csv("mfmNI225.csv", sep = ";", dec = ",")
mfmjpy <- read.csv("mfmJPY.csv", sep = ";", dec = ",")
mfmgold <- read.csv("mfmGOLD.csv", sep = ";", dec = ",")
mfmeur <- read.csv("mfmEUR.csv", sep = ";", dec = ",")
mfmmsci <- read.csv("mfmMSCI.csv", sep = ";", dec = ",")
mfmes50 <- read.csv("mfmES50.csv", sep = ";", dec = ",")
mfmdji <- read.csv("mfmDJI.csv", sep = ";", dec = ",")

## renaming, dropping

colnames(mfmdji) <- c("Date", "dji", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmdji$Date <- as.Date(mfmdji$Date, "%d.%m.%Y")
mfmdji <- subset(mfmdji, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmes50) <- c("Date", "es50", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmes50$Date <- as.Date(mfmes50$Date, "%d.%m.%Y")
mfmes50 <- subset(mfmes50, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmeur) <- c("Date", "eur", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmeur$Date <- as.Date(mfmeur$Date, "%d.%m.%Y")
mfmeur <- subset(mfmeur, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmgold) <- c("Date", "gold", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmgold$Date <- as.Date(mfmgold$Date, "%d.%m.%Y")
mfmgold <- subset(mfmgold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmjpy) <- c("Date", "jpy", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmjpy$Date <- as.Date(mfmjpy$Date, "%d.%m.%Y")
mfmjpy <- subset(mfmjpy, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmmsci) <- c("Date", "msci", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmmsci$Date <- as.Date(mfmmsci$Date, "%d.%m.%Y")
mfmmsci <- subset(mfmmsci, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmni225) <- c("Date", "ni225", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmni225$Date <- as.Date(mfmni225$Date, "%d.%m.%Y")
mfmni225 <- subset(mfmni225, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmoil) <- c("Date", "oil", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmoil$Date <- as.Date(mfmoil$Date, "%d.%m.%Y")
mfmoil <- subset(mfmoil, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
colnames(mfmsp500) <- c("Date", "sp500", "three", "Mkt.RF", "SMB", "HML", "RF", "five", "Mkt.RF.1", "SMB.1", "HML.1", "RMW", "CMA", "RF.1")
mfmsp500$Date <- as.Date(mfmsp500$Date, "%d.%m.%Y")
mfmsp500 <- subset(mfmsp500, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))


mfmdji[,2] <- mfmdji[,2]*100
mfmes50[,2] <- mfmes50[,2]*100
mfmeur[,2] <- mfmeur[,2]*100
mfmgold[,2] <- mfmgold[,2]*100
mfmjpy[,2] <- mfmjpy[,2]*100
mfmmsci[,2] <- mfmmsci[,2]*100
mfmni225[,2] <- mfmni225[,2]*100
mfmoil[,2] <- mfmoil[,2]*100
mfmsp500[,2] <- mfmsp500[,2]*100

## creating subsets

mfmdjics <- subset(mfmdji, Date >= as.Date("2020-01-01"))
mfmdjibc <- subset(mfmdji, Date < as.Date("2020-01-01"))
mfmes50cs <- subset(mfmes50, Date >= as.Date("2020-01-01"))
mfmes50bc <- subset(mfmes50, Date < as.Date("2020-01-01"))
mfmeurcs <- subset(mfmeur, Date >= as.Date("2020-01-01"))
mfmeurbc <- subset(mfmeur, Date < as.Date("2020-01-01"))
mfmgoldcs <- subset(mfmgold, Date >= as.Date("2020-01-01"))
mfmgoldbc <- subset(mfmgold, Date < as.Date("2020-01-01"))
mfmjpycs <- subset(mfmjpy, Date >= as.Date("2020-01-01"))
mfmjpybc <- subset(mfmjpy, Date < as.Date("2020-01-01"))
mfmmscics <- subset(mfmmsci, Date >= as.Date("2020-01-01"))
mfmmscibc <- subset(mfmmsci, Date < as.Date("2020-01-01"))
mfmni225cs <- subset(mfmni225, Date >= as.Date("2020-01-01"))
mfmni225bc <- subset(mfmni225, Date < as.Date("2020-01-01"))
mfmoilcs <- subset(mfmoil, Date >= as.Date("2020-01-01"))
mfmoilbc <- subset(mfmoil, Date < as.Date("2020-01-01"))
mfmsp500cs <- subset(mfmsp500, Date >= as.Date("2020-01-01"))
mfmsp500bc <- subset(mfmsp500, Date < as.Date("2020-01-01"))

## building a loop for one factor

set <- list("", "bc", "cs")
cryp <- list("dji" , "es50" , "eur" , "gold" , "jpy" , "msci" ,  "ni225" , "oil" , "sp500")

for(h in set){
  for(i in cryp) {
    
    sink("cryp.txt")
    writeLines(paste("one <- lm(", i, "~ Mkt.RF, data=mfm",i, h, ")",sep=""))
    closeAllConnections()
    source(file = "cryp.txt")
    
    hallo <- coeftest(one,vcov=vcovHC(one,type="HC0",vcov. = vcovHC))
    sink(paste("1mfmoutputtrad/",i,h,".txt",sep=""))
    print(hallo)
    closeAllConnections()
  }
}

## building a loop for three factors

set <- list("", "bc", "cs")
cryp <- list("dji" , "es50" , "eur" , "gold" , "jpy" , "msci" ,  "ni225" , "oil" , "sp500")

for(h in set){
  for(i in cryp) {
    
    sink("cryp.txt")
    writeLines(paste("three <- lm(", i, "~ Mkt.RF+SMB+HML, data=mfm",i, h, ")",sep=""))
    closeAllConnections()
    source(file = "cryp.txt")
    
    hallo <- coeftest(three,vcov=vcovHC(three,type="HC0",vcov. = vcovHC))
    sink(paste("3mfmoutputtrad/",i,h,".txt",sep=""))
    print(hallo)
    closeAllConnections()
  }
}

## building a loop for five factors

set <- list("", "bc", "cs")
cryp <- list("dji" , "es50" , "eur" , "gold" , "jpy" , "msci" ,  "ni225" , "oil" , "sp500")

for(h in set){
  for(i in cryp) {
    
    sink("cryp.txt")
    writeLines(paste("five <- lm(", i, "~ Mkt.RF.1+SMB.1+HML.1+RMW+CMA, data=mfm",i, h, ")",sep=""))
    closeAllConnections()
    source(file = "cryp.txt")
    
    hallo <- coeftest(five,vcov=vcovHC(five,type="HC0",vcov. = vcovHC))
    sink(paste("5mfmoutputtrad/",i,h,".txt",sep=""))
    print(hallo)
    closeAllConnections()
  }
}

## loop for the excel file

for(x in 1:3){
  for(y in 1:9){
    xn=set[x]
    yn=cryp[y]
    
    martin <- paste(yn,xn, sep="")
    print(martin)
  }}




## DOING IT FOR GOLD

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("./DATA_NEW/aggregate/sm aufgesplittet/GOLD")

datadjigold <- as.data.frame(read.csv("DJIGOLD.csv", sep = ";", dec = ","))
dataes50gold <- as.data.frame(read.csv("ES50GOLD.csv", sep = ";", dec = ","))
dataeurgold <- as.data.frame(read.csv("EURGOLD.csv", sep = ";", dec = ","))
datajpygold <- as.data.frame(read.csv("JPYGOLD.csv", sep = ";", dec = ","))
datamscigold <- as.data.frame(read.csv("MSCIGOLD.csv", sep = ";", dec = ","))
datani225gold <- as.data.frame(read.csv("NI225GOLD.csv", sep = ";", dec = ","))
dataoilgold <- as.data.frame(read.csv("OILGOLD.csv", sep = ";", dec = ","))
datasp500gold <- as.data.frame(read.csv("SP500GOLD.csv", sep = ";", dec = ","))

colnames(datadjigold) <- c("Date", "dji", "gold" )
colnames(dataes50gold) <- c("Date", "es50", "gold" )
colnames(dataeurgold) <- c("Date", "eur", "gold" )
colnames(datajpygold) <- c("Date", "jpy", "gold" )
colnames(datamscigold) <- c("Date", "msci", "gold" )
colnames(datani225gold) <- c("Date", "ni225", "gold" )
colnames(dataoilgold) <- c("Date", "oil", "gold" )
colnames(datasp500gold) <- c("Date", "sp500", "gold" )

datadjigold$Date <- as.Date(datadjigold$Date, "%d.%m.%Y")
datadjigold <- subset(datadjigold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataes50gold$Date <- as.Date(dataes50gold$Date, "%d.%m.%Y")
dataes50gold <- subset(dataes50gold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataeurgold$Date <- as.Date(dataeurgold$Date, "%d.%m.%Y")
dataeurgold <- subset(dataeurgold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datajpygold$Date <- as.Date(datajpygold$Date, "%d.%m.%Y")
datajpygold <- subset(datajpygold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datamscigold$Date <- as.Date(datamscigold$Date, "%d.%m.%Y")
datamscigold <- subset(datamscigold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datani225gold$Date <- as.Date(datani225gold$Date, "%d.%m.%Y")
datani225gold <- subset(datani225gold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
dataoilgold$Date <- as.Date(dataoilgold$Date, "%d.%m.%Y")
dataoilgold <- subset(dataoilgold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))
datasp500gold$Date <- as.Date(datasp500gold$Date, "%d.%m.%Y")
datasp500gold <- subset(datasp500gold, as.Date("2013-04-30") < Date & Date < as.Date("2020-08-01"))

datadjigoldcs <- subset(datadjigold, Date >= as.Date("2020-01-01"))
datadjigoldbc <- subset(datadjigold, Date < as.Date("2020-01-01"))
dataes50goldcs <- subset(dataes50gold, Date >= as.Date("2020-01-01"))
dataes50goldbc <- subset(dataes50gold, Date < as.Date("2020-01-01"))
dataeurgoldcs <- subset(dataeurgold, Date >= as.Date("2020-01-01"))
dataeurgoldbc <- subset(dataeurgold, Date < as.Date("2020-01-01"))
datajpygoldcs <- subset(datajpygold, Date >= as.Date("2020-01-01"))
datajpygoldbc <- subset(datajpygold, Date < as.Date("2020-01-01"))
datamscigoldcs <- subset(datamscigold, Date >= as.Date("2020-01-01"))
datamscigoldbc <- subset(datamscigold, Date < as.Date("2020-01-01"))
datani225goldcs <- subset(datani225gold, Date >= as.Date("2020-01-01"))
datani225goldbc <- subset(datani225gold, Date < as.Date("2020-01-01"))
dataoilgoldcs <- subset(dataoilgold, Date >= as.Date("2020-01-01"))
dataoilgoldbc <- subset(dataoilgold, Date < as.Date("2020-01-01"))
datasp500goldcs <- subset(datasp500gold, Date >= as.Date("2020-01-01"))
datasp500goldbc <- subset(datasp500gold, Date < as.Date("2020-01-01"))

## Model-estimation as function

doitgold <- function(setgold, crypgold,tradgold){
  
  sink("trad.txt")
  writeLines(paste("datau <- data", tradgold,"gold", setgold,"$", tradgold,sep=""))
  closeAllConnections()
  source(file = "trad.txt")
  
  sink("cryp.txt")
  writeLines(paste("crypto <- data", tradgold,"gold",setgold, "$", crypgold,sep=""))
  closeAllConnections()
  source(file = "cryp.txt")
  
  crypto <- na.omit(crypto)
  rem <- length(datau)-length(crypto)+1
  maxi <- length(datau)
  datau <- datau[rem:maxi]
  
  quan10 <- quantile(datau, probs=seq(0,1,0.1), na.rm=TRUE)
  quan5 <- quantile(datau, probs=seq(0,1,0.05), na.rm=TRUE)
  quan1 <- quantile(datau, probs=seq(0,1,0.01), na.rm=TRUE)
  dataSP <- as.data.frame(datau)
  colnames(dataSP) <- "ret"
  dataSP$tenp <- ifelse(dataSP$ret < quan10[2], 1,0)
  dataSP$fivep <- ifelse(dataSP$ret < quan5[2], 1,0)
  dataSP$onep <- ifelse(dataSP$ret < quan1[2], 1,0)
  dataSP$one <- 1
  
  ## garch
  
  library(fGarch)
  library(rugarch)
  
  fit.spec <- ugarchspec(variance.model     = list(model = "sGARCH",
                                                   garchOrder = c(1, 1)), 
                         mean.model         = list(armaOrder = c(0, 0),
                                                   include.mean = TRUE,
                                                   external.regressors = cbind(dataSP$ret*dataSP$one, dataSP$ret*dataSP$tenp, dataSP$ret*dataSP$fivep, dataSP$ret*dataSP$onep)), 
                         distribution.model = "norm")
  fit      <- ugarchfit(data = crypto, spec = fit.spec, trace=1)
  sink(paste("garchoutputGOLD/",crypgold,tradgold,setgold,".txt",sep=""))
  print(fit)
  closeAllConnections()
  
}

setgold <- list("", "bc", "cs")
crypgold <- list("gold")
tradgold <- list("dji", "es50", "eur", "jpy", "msci", "ni225", "oil", "sp500")

for(x in setgold){
  for(y in crypgold){
    for(z in tradgold){
      #daten=x
      #cryp=y
      #trad=z
      
      doitgold(x,y,z)
      
    }}}

## for trying
#doitgold("cs","gold","dji")

for(x in 1:3){
  for(y in 1:1){
    for(z in 1:8){
      xn=setgold[x]
      yn=crypgold[y]
      zn=tradgold[z]
      
      guido <- paste(yn,zn,xn, sep="")
      print(guido)
    }}}

